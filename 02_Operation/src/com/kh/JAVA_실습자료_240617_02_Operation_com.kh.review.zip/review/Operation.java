package com.kh.review;

public class Operation {

	public static void main(String[] args) {

		inDecrease();

	}
	
	public static void inDecrease() {
		/*
		 * 증감연산자 (단항연산자)
		 * 	++ : 변수에 담긴 값을 1씩 증가시켜주는 연산자
		 * 		ex) ++변수 / 변수++
		 * 	-- : 변수에 담긴 값을 1씩 감소시켜주는 연산자
		 * 		ex) --변수 / 변수--
		 * 
		 * * 증감연사자 외에 다른 연산자도 있을 경우 처리 순서
		 *  전위연산 : 증감연산자를 먼저 처리한 후에 다른 연산을 수행
		 *  		(증감연산자)변수 : "선증감" 후처리
		 *  후위연산 : 다른 연산을 먼저 수행한 후 증감연산자를 수행
		 *  		변수(증감연산자) : 선처리 "후증감"
		 */
		
		int n1 = 10;
		System.out.println("전위 연산 적용 전 n1의 값 : " + n1);	// 10
		System.out.println("1회 수행 결과 : " + ++n1);			// 11
		System.out.println("2회 수행 결과 : " + ++n1);			// 12
		System.out.println("3회 수행 결과 : " + ++n1);			// 13
		System.out.println("최종 n1 : " + n1);				// 13
		
		System.out.println("------------------------------");
		
		int n2=10;
		System.out.println("후위 연산 적용 전 n2의 값 : " + n2);	// 10
		System.out.println("1회 수행 결과 : " + n2++);			// 10
		System.out.println("2회 수행 결과 : " + n2++);			// 11
		System.out.println("3회 수행 결과 : " + n2++);			// 12
		System.out.println("최종 n2 : " + n2);				// 13
		
		System.out.println("---------------------");
		
		int a=10;
		int b=20;
		int c=30;
		
		System.out.println(a++);					//=>
		System.out.println((++a) + (b++));			//=>
		System.out.println((a++) + (--b) + (--c));	//=>
		
		System.out.printf("a : %d, b : %d, c : %d\n", a, b, c);
													//=>
	}
	

}





